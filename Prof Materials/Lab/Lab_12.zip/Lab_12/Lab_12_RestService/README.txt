Lab answer based on Lab_11_MVC vs Lab_11_4aMVC

Has User..Item..Credentials...in REST services

Login:
admin/admin
guest/guest