package edu.mum.dao;

import edu.mum.domain.CreditCard;

public interface CreditCardDao extends GenericDao<CreditCard> {
      
}
